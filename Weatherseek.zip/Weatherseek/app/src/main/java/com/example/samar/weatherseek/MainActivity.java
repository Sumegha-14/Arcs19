package com.example.samar.weatherseek;

import android.content.Context;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends AppCompatActivity {
    TextView dispweather;
    EditText cityname;
    public void getweather(View view){
        try {
            DownloadTask task = new DownloadTask();
            String encodedmessage = URLEncoder.encode(cityname.getText().toString(), "UTF-8");
            task.execute("http://api.openweathermap.org/data/2.5/weather?q=" + encodedmessage + "&units=metric&APPID=1a11e14b7aed2a825c06a3375f073cb4");
            InputMethodManager mgr = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            mgr.hideSoftInputFromWindow(cityname.getWindowToken(), 0);
        }
        catch(Exception e){
            e.printStackTrace();
            dispweather.setText("Could not find the city :( ,please check for spelling errors");

        }
    }
    public class DownloadTask extends AsyncTask<String,Void,String>{

        @Override
        protected String doInBackground(String... strings) {
            String result="";
            try {
                URL url=new URL(strings[0]);
                HttpURLConnection urlConnection=(HttpURLConnection)url.openConnection();
                InputStream in=urlConnection.getInputStream();
                InputStreamReader reader=new InputStreamReader(in);
                int data;
                data=reader.read();
                while(data!=-1){
                    char current=(char) data;
                    result+=current;
                    data=reader.read();
                }
                return result;
            } catch (Exception e) {
                e.printStackTrace();
                return null;
            }
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            try {
                String message="";

                JSONObject jsonObject=new JSONObject(s);
                String weatherinfo=jsonObject.getString("weather");
                String temperature=jsonObject.getString("main");
                JSONArray arr=new JSONArray(weatherinfo);
              Pattern p=Pattern.compile("temp\":(.*?),");
                        Matcher m=p.matcher(temperature);
              while(m.find()){
                  Log.i("temperature",m.group(1)+"°C");
                  message+="Temperature : "+m.group(1)+"°C"+"\n";
              }
                Log.i("array",arr.toString());

                for(int i=0;i<arr.length();i++){

                    JSONObject jsonpart=arr.getJSONObject(i);
                    String main=jsonpart.getString("main");
                    String description=jsonpart.getString("description");
                    if(!main.equals("") && !description.equals("")){
                        message+=main+" : "+description+"\n";
                    }

                    Log.i("main",jsonpart.getString("main"));
                    Log.i("description",jsonpart.getString("description"));
                }
                if(!message.equals("")){
                    dispweather.setText(message);
                }
                else{
                    dispweather.setText("Could not find the city :( ,please check for spelling errors");
                }
            } catch (Exception e) {
                e.printStackTrace();
                dispweather.setText("Could not find the city :( ,please check for spelling errors");
            }
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dispweather=(TextView)findViewById(R.id.dispweather);
        cityname=(EditText)findViewById(R.id.cityname);

    }
}
